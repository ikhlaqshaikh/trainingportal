﻿using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ReadSharedDriveFiles
{
    class Program
    {
        //define newtork drive path and network credentials to access the drive
        static string networkPath = @"\\nas00912pn\\Data\UHC_Proces_Engg\\.net projects backup\\test docs";
        //static NetworkCredential credentials = new NetworkCredential(@"userId", "password");
        static void Main(string[] args)
        {
            //using (new SharedDriveConnection(networkPath, credentials))
            //{
            string[] files = Directory.GetFiles(networkPath);
            foreach (var file in files)
            {
                string ext = Path.GetExtension(file);
                bool pdfFlag = true;
                if (ext.ToLower() == ".png" || ext.ToLower() == ".jpg" || ext.ToLower() == ".gif" || ext.ToLower() == ".pdf")
                {
                    if (ext.ToLower() == ".pdf")
                    {
                        PdfReader pdfReader = new PdfReader(file);
                        int numberOfPages = pdfReader.NumberOfPages;
                        if (numberOfPages == 1)
                            pdfFlag = false;
                        pdfReader.Close();

                    }

                    if (pdfFlag)
                        File.Delete(file);

                }
            }
            //}
        }

      
    }
}
