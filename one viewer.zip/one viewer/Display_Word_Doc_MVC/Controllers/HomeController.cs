﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.IO;
using ClosedXML.Excel;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.Drawing.Imaging;
using Syncfusion.OfficeChartToImageConverter;
using Syncfusion.Presentation;
using Syncfusion.PresentationToPdfConverter;
using Syncfusion.Pdf;
using Aspose.Diagram;

namespace Display_Word_Doc_MVC.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UploadFile()
        {
            try
            {
                var postedFile = Request.Files[0];

                object documentFormat = 8;
                string randomName = DateTime.Now.Ticks.ToString();
                object htmlFilePath = Server.MapPath("~/Temp/") + randomName + ".htm";
                string directoryPath = Server.MapPath("~/Temp/") + randomName + "_files";
                object fileSavePath = Server.MapPath("~/Temp/") + Path.GetFileName(postedFile.FileName);

                //If Directory not present, create it.
                if (!Directory.Exists(Server.MapPath("~/Temp/")))
                {
                    
                    Directory.CreateDirectory(Server.MapPath("~/Temp/"));
                }
                else
                {
                    Directory.Delete(Server.MapPath("~/Temp/"), true);
                    Directory.CreateDirectory(Server.MapPath("~/Temp/"));
                }
                

                //Upload the word document and save to Temp folder.
                postedFile.SaveAs(fileSavePath.ToString());
                string extention = Path.GetExtension(fileSavePath.ToString().ToLower());
            
                
                if (extention == ".pptx")
                {
                   
                    //// Save the presentation as PDF
                    string pptPath = Server.MapPath("~/Temp/") + Path.GetFileName(postedFile.FileName);//.Replace(".pptx", ".pdf");
                    //presentation.Save(Server.MapPath("~/Temp/") + pdfPath, SaveFormat.Pdf);

                 

                    IPresentation pptxDoc = Presentation.Open(pptPath);

                    //Creates an instance of ChartToImageConverter and assigns it to ChartToImageConverter property of Presentation
                    pptxDoc.ChartToImageConverter = new ChartToImageConverter();

                    //Converts the PowerPoint Presentation into PDF document
                    PdfDocument pdfDocument = PresentationToPdfConverter.Convert(pptxDoc);

                    //Saves the PDF document
                    pdfDocument.Save(Server.MapPath("~/Temp/") + Path.GetFileName(postedFile.FileName).Replace(".pptx", ".pdf"));

                    //Closes the PDF document
                    pdfDocument.Close(true);
                    
                    //Closes the Presentation
                    pptxDoc.Close();

                    //byte[] AsBytes = System.IO.File.ReadAllBytes(Server.MapPath("~/Temp/") + Path.GetFileName(postedFile.FileName).Replace(".pptx", ".pdf"));
                    //string bes64String = Convert.ToBase64String(AsBytes);
                    ViewBag.HtmlContent = Path.GetFileName(postedFile.FileName).Replace(".pptx", ".pdf");
                }
                else if (extention == ".csv")
                {
                    DataTable dt = GetDataTableFromCsv(fileSavePath.ToString(), true);
                    string csvHtml = ConvertDataTableToHTML(dt);
                    ViewBag.HtmlContent = csvHtml;
                }
                else if (extention == ".xlsx" || extention == ".xls")
                {
                    //Open the word document in background.
                    List<WorkSheetString> content = ReadExcel(fileSavePath.ToString());
                    ViewBag.HtmlContent = content;

                }
                else if (extention == ".vsd" || extention == ".vsdx")
                {
                    // For complete examples and data files, please go to https://github.com/aspose-diagram/Aspose.Diagram-for-.NET
                    // The path to the documents directory.
                    //string dataDir = RunExamples.GetDataDir_LoadSaveConvert();

                    // Call the diagram constructor to load a VSD diagram
                    Diagram diagram = new Diagram(fileSavePath.ToString());

                    MemoryStream pdfStream = new MemoryStream();
                    // Save diagram
                    diagram.Save(pdfStream, SaveFileFormat.PDF);

                    // Create a PDF file
                    FileStream pdfFileStream = new FileStream(Server.MapPath("~/Temp/")+Path.GetFileName(postedFile.FileName).Replace(extention, ".pdf"), FileMode.Create, FileAccess.Write);
                    pdfStream.WriteTo(pdfFileStream);
                    pdfFileStream.Close();

                    pdfStream.Close();
                    ViewBag.HtmlContent = Path.GetFileName(postedFile.FileName).Replace(extention, ".pdf");
                    extention = ".pdf";

                   // TestFindAndRemoveTextOnAllPages(Server.MapPath("~/Temp/") + Path.GetFileName(postedFile.FileName), Server.MapPath("~/Temp/") + Path.GetFileName(postedFile.FileName),new string[]{ "Created with Evaluation", "version of Aspose.Diagram (c)."});

                    // Display Status.
                    //System.Console.WriteLine("Conversion from vsd to pdf performed successfully.");
                    // ViewBag.HtmlContent = Path.GetFileName(postedFile.FileName);

                }
                else if (extention == ".json" || extention == ".html" || extention == ".htm" || extention == ".txt" || extention == ".rtf" || extention == ".css" || extention == ".sql" || extention == ".js" || extention == ".ts" || extention == ".vb" || extention == ".cs" || extention == ".py" || extention == ".log" || extention == ".xml" || extention == ".sh" || extention == ".bat")
                {

                    // Read entire text file content in one string  
                    string jsonString = System.IO.File.ReadAllText(fileSavePath.ToString());
                    ViewBag.HtmlContent = jsonString;
                }
                else if (extention == ".tiff")
                {
                    string pngPath = Path.GetFileName(postedFile.FileName).Replace(".tiff", ".png");
                    using (var tiff = new System.Drawing.Bitmap(fileSavePath.ToString()))
                    {
                        tiff.Save(Server.MapPath("~/Temp/") + pngPath, ImageFormat.Png);
                    }
                    //System.Drawing.Bitmap.FromFile(fileSavePath.ToString()).Save(Server.MapPath("~/Temp/") + pngPath, System.Drawing.Imaging.ImageFormat.Png);
                    byte[] AsBytes = System.IO.File.ReadAllBytes(Server.MapPath("~/Temp/") + pngPath);
                    string bes64String = Convert.ToBase64String(AsBytes);
                    ViewBag.HtmlContent = bes64String;
                }
                else if (extention == ".jpg" || extention == ".png" || extention == ".bmp" || extention == ".gif" || extention == ".ico")
                {
                    //Open the word document in background.
                    byte[] AsBytes = System.IO.File.ReadAllBytes(fileSavePath.ToString());
                    string bes64String = Convert.ToBase64String(AsBytes);
                    ViewBag.HtmlContent = bes64String;

                }
                else if(extention==".pdf")
                {
                   
                    ViewBag.HtmlContent =  Path.GetFileName(postedFile.FileName);
                }

                ViewBag.DocType = extention;
                //if (extention != ".vsd")
                //    Directory.Delete(Server.MapPath("~/Temp/"), true);

                ////Delete the Uploaded Word File.
                //System.IO.File.Delete(fileSavePath.ToString());
                ////delete dirs
                //foreach (var directory in Directory.GetDirectories(Server.MapPath("~/Temp/")))
                //{
                //    System.IO.Directory.Delete(directory);
                //}
                ////delete other files
                //foreach (var file in Directory.GetFiles(Server.MapPath("~/Temp/")))
                //{
                //    System.IO.Directory.Delete(file);
                //}
            }
            catch(Exception ex)
            {
                ViewBag.Error = "Some error occured while rendering the document, please try again !";
                Directory.Delete(Server.MapPath("~/Temp/"), true);
            }
            
            return PartialView("_viewer");

        }

        public void removeTextFromPDF()
        {
            
      //      Document pdfDocument = new Aspose.Pdf.Document(@"c:/ pdftest / 2.pdf");

      //// search all TextFragments

      //      TextFragmentAbsorber textFragmentAbsorber = new TextFragmentAbsorber(@"[\S]+");

      //      textFragmentAbsorber.TextSearchOptions.IsRegularExpressionUsed = true;

      //      pdfDocument.Pages.Accept(textFragmentAbsorber);

      //      TextFragmentCollection textFragmentCollection = textFragmentAbsorber.TextFragments;

      //      foreach (TextFragment textFragment in textFragmentCollection)

      //      {

      //          textFragment.Text = "";

      //      }

      //      pdfDocument.Save("c:/ pdftest / TextRemoved.pdf");
        }
        public System.Data.DataTable GetDataTableFromCsv(string path, bool isFirstRowHeader)
        {
            string header = isFirstRowHeader ? "Yes" : "No";

            string pathOnly = Path.GetDirectoryName(path);
            string fileName = Path.GetFileName(path);

            string sql = @"SELECT * FROM [" + fileName + "]";

            using (OleDbConnection connection = new OleDbConnection(
                      @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathOnly +
                      ";Extended Properties=\"Text;HDR=" + header + "\""))
            using (OleDbCommand command = new OleDbCommand(sql, connection))
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
            {
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataTable.Locale = CultureInfo.CurrentCulture;
                adapter.Fill(dataTable);
                return dataTable;
            }


        }
        

        public List<WorkSheetString> ReadExcel(string filePath)
        {
            List<WorkSheetString> content = new List<WorkSheetString>();
            //Save the uploaded Excel file.

            //Open the Excel file using ClosedXML.
            using (XLWorkbook workBook = new XLWorkbook(filePath))
            {
                int sheetIndex = 0;
                foreach(IXLWorksheet workSheet in workBook.Worksheets)
                {
                    //Read the first Sheet from Excel file.
                   // IXLWorksheet workSheet = workBook.Worksheet(1);

                    //Create a new DataTable.
                    System.Data.DataTable dt = new System.Data.DataTable();

                    //Loop through the Worksheet rows.
                    bool firstRow = true;
                    foreach (IXLRow row in workSheet.Rows())
                    {
                        //Use the first row to add columns to DataTable.
                        if (firstRow)
                        {
                            foreach (IXLCell cell in row.Cells())
                            {
                                dt.Columns.Add(cell.Value.ToString());
                            }
                            firstRow = false;
                        }
                        else
                        {
                            //Add rows to DataTable.
                            dt.Rows.Add();
                            int i = 0;
                            foreach (IXLCell cell in row.Cells())
                            {
                                dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();
                                i++;
                            }
                        }
                    }
                    //ds.Tables.Add(dt);
                    string htmlContent = ConvertDataTableToHTML(dt);
                    content.Add(new WorkSheetString { name = workSheet.Name, content = htmlContent });
                    //ds.Tables[sheetIndex].TableName = workSheet.Name;
                    sheetIndex++;

                }

            }
            return content;
        }
        public string ConvertDataTableToHTML(System.Data.DataTable dt)
        {
            string html = "<table class='table'>";
            //add header row
            html += "<thead><tr>";
            for (int i = 0; i < dt.Columns.Count; i++)
                html += "<th style='background:#ddd;color:#000'>" + dt.Columns[i].ColumnName + "</td>";
            html += "</thead></tr><tbody>";
            //add rows
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                html += "<tr>";
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                        html += "<td>" + (dt.Rows[i][j] != null && dt.Rows[i][j].ToString()!=""?dt.Rows[i][j].ToString():"&nbsp;") + "</td>";
                }
                html += "</tr>";
            }
            html += "</tbody></table>";
            return html;
        }
        public class WorkSheetString
        {
            public string name { get; set; }
            public  string  content { get; set; }
        }


    }
}