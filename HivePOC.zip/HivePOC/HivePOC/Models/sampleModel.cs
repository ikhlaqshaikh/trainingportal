﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HivePOC.Models
{
    public class SampleModel
    {
        public string mpin { get; set; }
        public string tax_id_nbr { get; set; }
        public string adr_id { get; set; }
        public string par_prov_ind { get; set; }
        public string cty_nm { get; set; }
        public string st_cd { get; set; }
        public string zip_cd { get; set; }
        public string zip_pls_4_cd { get; set; }
        public string cnty_cd { get; set; }
        public string fst_nm { get; set; }
        public string mdl_nm { get; set; }
        public string lst_nm { get; set; }
        public string dlgt_cd { get; set; }
        public string phys_hosp { get; set; }
        public string deligated_status { get; set; }
        public string sourcetable { get; set; }
        public string input_date { get; set; }
    }
}