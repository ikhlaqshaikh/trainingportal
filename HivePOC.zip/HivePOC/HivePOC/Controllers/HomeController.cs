﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Odbc;
using System.Data;
using HivePOC.Models;
using System.Text;
using System.Reflection;

namespace HivePOC.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(string mpin = null)
        {
            try
            {
                mpin = mpin ?? Request.Params["mpin"].ToString();
                //var connection = @"DRIVER={Sample MapR Hive DSN};                                       

                //                        Host=apsrp09163;

                //                        Port=10585;
                //                        UID= abledrep;
                //                        PWD=@bledrep1;
                //                        Schema=able_usrs;



                //                        HiveServerType=2;

                //                        ApplySSPWithQueries=1;

                //                        AsyncExecPollInterval=100;

                //                        AuthMech=0;

                //                        CAIssuedCertNamesMismatch=0;";
                var connection = new OdbcConnection()
                {
                    ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["HiveConnection"].ToString()
                };
                var adp = new OdbcDataAdapter("select * from able_usrs.able_rep_sample_data where mpin='" + mpin + "' limit 20", connection);
                var ds = new DataSet();
                adp.Fill(ds);
                if (ds.Tables.Count > 0)
                {

                    //List<SampleModel> list = Helper.DataTableToList<SampleModel>(ds.Tables[0]);
                    //var html = GetMyTable(list);
                    var html = ConvertDataTableToHTML(ds.Tables[0]);
                    ViewBag.Data = html;
                }
            }
            catch (Exception ex)
            {

            }

            return View();
        }
        public static string ConvertDataTableToHTML(DataTable dt)
        {
            string html = "<table class='table table-bordered'>";
            //add header row
            html += "<thead><tr>";
            for (int i = 0; i < dt.Columns.Count; i++)
                html += "<th>" + dt.Columns[i].ColumnName + "</th>";
            html += "</thead></tr>";
            //add rows
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                html += "<tr>";
                for (int j = 0; j < dt.Columns.Count; j++)
                    html += "<td>" + dt.Rows[i][j].ToString() + "</td>";
                html += "</tr>";
            }
            html += "</table>";
            return html;
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
      

        public static string GetMyTable<T>(IEnumerable<T> list)
        {

            StringBuilder sb = new StringBuilder();
            sb.Append("<TABLE class='table table-bordered'>\n");
            sb.Append("<THEAD>\n");
            sb.Append("<TR>\n");
           
            foreach (var item in list)
            {
                
                sb.Append("<TR>\n");
                foreach (var fxn in typeof(SampleModel).GetProperties())
                {
                    if(list.ToList().IndexOf(item)==0)
                    {
                       

                            sb.Append("<TH>\n");
                            sb.Append(fxn.Name);
                            sb.Append("</TH>\n");
                        

                        sb.Append("</TR>\n");
                        sb.Append("</THEAD>\n");
                    }
                    sb.Append("<TD>");
                    object value = fxn.GetValue(item);
                    sb.Append(value);
                    sb.Append("</TD>");
                }
                sb.Append("</TR>\n");
            }
            sb.Append("</TABLE>");

            return sb.ToString();
        }
        public static object GetPropValue(object source, string propertyName)
        {
            var property = source.GetType().GetRuntimeProperties().FirstOrDefault(p => string.Equals(p.Name, propertyName, StringComparison.OrdinalIgnoreCase));
            return property?.GetValue(source);
        }

    }
}